import cv2
import json
import sys

def time_to_seconds(time_str):
    """Convert MM:SS or SS format to seconds."""
    parts = time_str.split(':')
    if len(parts) == 2:
        return int(parts[0]) * 60 + int(parts[1])
    elif len(parts) == 1:
        return int(parts[0])
    raise ValueError(f"Invalid time format: {time_str}")

# Ensure the video file and optionally time frames are provided
if len(sys.argv) < 2:
    print("Usage: python detect_faces.py <input_video> [<start_time>-<end_time> ...]")
    sys.exit(1)

input_video = sys.argv[1]

# Parse the time frames if provided
time_frames = []
if len(sys.argv) > 2:
    for arg in sys.argv[2:]:
        try:
            start_time, end_time = arg.split('-')
            start_seconds = time_to_seconds(start_time)
            end_seconds = time_to_seconds(end_time)
            time_frames.append((start_seconds, end_seconds))
        except ValueError:
            print(f"Invalid time frame format: {arg}")
            sys.exit(1)

# Load the Haarcascade file for face detection
haarcascade_path = '/usr/share/opencv4/haarcascades/haarcascade_frontalface_default.xml'
face_cascade = cv2.CascadeClassifier(haarcascade_path)

# Verify that the Haarcascade file was loaded successfully
if face_cascade.empty():
    print(f"Error loading Haarcascade file: {haarcascade_path}")
    sys.exit(1)

# Open the video file
cap = cv2.VideoCapture(input_video)
if not cap.isOpened():
    print(f"Error opening video file: {input_video}")
    sys.exit(1)

# Retrieve video properties
fps = int(cap.get(cv2.CAP_PROP_FPS))
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

# Dictionary to hold face coordinates for each frame
face_coords = {}

# Process each frame of the video
frame_number = 0
while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Convert current frame number to time (in seconds)
    current_time = frame_number / fps

    # Determine if the current time is within any specified time frames
    in_time_frame = any(start_time <= current_time <= end_time for start_time, end_time in time_frames)

    if in_time_frame or not time_frames:
        # Detect faces in the frame
        faces = face_cascade.detectMultiScale(frame, scaleFactor=1.3, minNeighbors=5)

        # Convert the detected faces to a list and store them in the dictionary
        if len(faces) > 0:
            face_coords[frame_number] = faces.tolist()
        else:
            face_coords[frame_number] = []

    frame_number += 1

cap.release()

# Save the detected face coordinates to a JSON file
output_json = f'{input_video}_faces.json'
with open(output_json, 'w') as f:
    json.dump(face_coords, f)

print(f"Face detection complete. Coordinates saved to {output_json}. Processed {frame_number} frames.")

