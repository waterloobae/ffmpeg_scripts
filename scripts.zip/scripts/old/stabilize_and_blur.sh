#!/bin/bash

# Check if the video file argument is provided
if [ "$#" -lt 1 ]; then
    echo "Usage: ./stabilize_and_blur.sh <input_video> [<start_time>-<end_time> ...]"
    exit 1
fi

input_video=$1
shift
time_frames="$@"

# Ensure the scripts are executable
chmod +x /home/thbae/bin/detect_faces.py
chmod +x /home/thbae/bin/blur_faces.py

# Email details
email_subject="Video Processing Completed"
email_body="The video processing job has been completed. The processed video is named: $blurred_video.\n\nCheck the log files for details."
recipient_email="terry.bae@google.com"  # Replace with your email address

# Step 1: Generate stabilization data in the background using nohup
nohup ffmpeg -i "$input_video" -vf vidstabdetect=shakiness=10:accuracy=15 -f null - > vidstabdetect.log 2>&1 &

# Wait for the stabilization data generation to complete
wait

# Step 2: Apply stabilization in the background using nohup
stabilized_video="stabilized_$input_video"
nohup ffmpeg -i "$input_video" -vf vidstabtransform=smoothing=30:input="transforms.trf" -c:v libx264 -preset medium -crf 23 "$stabilized_video" > vidstabtransform.log 2>&1 &

# Wait for the stabilization process to complete
wait

# Step 3: Run face detection on the stabilized video with time frames in the background using nohup
nohup python3 /home/thbae/bin/detect_faces.py "$stabilized_video" $time_frames > detect_faces.log 2>&1 &

# Wait for the face detection process to complete
wait

# Step 4: Run the blur application script on the stabilized video in the background using nohup
nohup python3 /home/thbae/bin/blur_faces.py "$stabilized_video" > blur_faces.log 2>&1 &

# Wait for the blur process to complete
wait

# Send an email notification
echo -e "$email_body" | mail -s "$email_subject" "$recipient_email"

echo "Video stabilization, face detection, and blurring have been completed. Check vidstabdetect.log, vidstabtransform.log, detect_faces.log, and blur_faces.log for details."

