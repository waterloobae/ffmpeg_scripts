#!/bin/bash

# Check if the video file argument is provided
if [ "$#" -lt 1 ]; then
    echo "Usage: ./blur_faces.sh <input_video> [<start_time>-<end_time> ...]"
    exit 1
fi

input_video=$1
shift
time_frames="$@"

# Ensure the scripts are executable
chmod +x /home/thbae/bin/detect_faces.py
chmod +x /home/thbae/bin/blur_faces.py

# Run the face detection script with time frames in the background using nohup
nohup python3 /home/thbae/bin/detect_faces.py "$input_video" $time_frames > ~/detect_faces.log 2>&1 &

# Wait for the face detection process to complete
wait

# Run the blur application script in the background using nohup
nohup python3 /home/thbae/bin/blur_faces.py "$input_video" > ~/blur_faces.log 2>&1 &

# Wait for the blur process to complete
wait

echo "Face detection and blurring process has been completed. Check detect_faces.log and blur_faces.log for details."

