import json
import subprocess
import sys

# Check if the video file argument is provided
if len(sys.argv) != 2:
    print("Usage: python blur_faces.py <input_video>")
    sys.exit(1)

input_video = sys.argv[1]

# Load the face coordinates
json_file = f'{input_video}_faces.json'
with open(json_file, 'r') as f:
    face_coords = json.load(f)

# Process in chunks to avoid too long command issues
chunk_size = 100  # Number of frames to process in one go
output_video = input_video
temp_video = f'{input_video}_temp.mp4'
filters = []

for frame_number, faces in face_coords.items():
    for face in faces:
        x, y, w, h = face
        filter_part = f"drawbox=x={x}:y={y}:w={w}:h={h}:color=black@0:t=max,boxblur=luma_radius=20:luma_power=1:chroma_radius=10:chroma_power=1:enable='between(n,{frame_number},{frame_number})'"
        filters.append(filter_part)
    
    # Process the filters in chunks
    if len(filters) >= chunk_size or frame_number == max(face_coords.keys()):
        ffmpeg_filter = ",".join(filters)
        
        command = [
            'ffmpeg',
            '-i', output_video,
            '-vf', ffmpeg_filter,
            '-c:v', 'libx264',
            '-c:a', 'copy',
            temp_video
        ]

        # Run the ffmpeg command
        subprocess.run(command)
        
        # Set temp_video as the new output for the next iteration
        output_video, temp_video = temp_video, output_video
        filters = []

# Rename the final output file
final_output = f'{input_video}_blurred.mp4'
subprocess.run(['mv', output_video, final_output])
print(f"Blurring complete. Output saved to {final_output}.")

