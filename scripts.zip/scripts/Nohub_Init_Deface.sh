#!/bin/bash

# Check if the correct number of arguments is provided
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <input_video_file>"
    exit 1
fi

# Assign argument to variable
INPUT_VIDEO=$1

# Run the Init_video.sh script with nohup
nohup bash Init_Deface.sh "$INPUT_VIDEO" > "${INPUT_VIDEO%.*}_nohup.log" 2>&1 &

echo "The process has been started with nohup. Check the log file for details: ${INPUT_VIDEO%.*}_nohup.log"

