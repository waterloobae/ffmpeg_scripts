#!/bin/bash

sudo sysctl -w kernel.apparmor_restrict_unprivileged_userns=0
sudo systemctl restart docker-desktop
