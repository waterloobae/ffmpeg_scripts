#!/bin/bash

# Check if a file is provided
if [ -z "$1" ]; then
  echo "Usage: $0 <file>"
  exit 1
fi

FILE=$1

# Activate the virtual environment
source /home/thbae/venvggl/bin/activate

# Run the Python script with nohup
nohup python /home/thbae/bin/upload_video.py --file="$FILE" \
                             --title="$FILE" \
                             --description="placeholder" \
                             --keywords="placeholder" \
                             --category="22" \
                             --privacyStatus="private" &

# Optional: Notify the user
echo "Video upload initiated for file: $FILE"

