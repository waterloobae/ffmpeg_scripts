#!/bin/bash

# Check if an input file was provided
if [ -z "$1" ]; then
  echo "Usage: $0 input_video.mp4"
  exit 1
fi

# Input video file
input_video="$1"

# Output stabilized video file (append "_stabilized" to the original filename)
output_video="${input_video%.*}_stabilized.mp4"

# Temporary file for the stabilization transform
transform_file="${input_video%.*}_transform.trf"

# Step 1: Generate the stabilization transform file
ffmpeg -i "$input_video" -vf vidstabdetect=shakiness=5:accuracy=15:result="$transform_file" -f null -

# Step 2: Apply the stabilization transform to the video
ffmpeg -i "$input_video" -vf vidstabtransform=input="$transform_file",unsharp=5:5:0.8:3:3:0.4 -vcodec libx264 -preset medium -crf 23 -acodec copy "$output_video"

# Clean up the temporary transform file
rm "$transform_file"

echo "Stabilized video saved as $output_video"
