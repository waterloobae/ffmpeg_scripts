#!/bin/bash

# Function to display the menu and collect input arguments one by one
collect_arguments() {
    echo "Please provide the following information:"

    read -p "Input video file: " INPUT_VIDEO
    read -p "Output video file: " OUTPUT_VIDEO
    read -p "Text to add (use double quotes if your text includes spaces or special characters): " TEXT
    read -p "X position of the text: " X_POSITION
    read -p "Y position of the text: " Y_POSITION
    read -p "Font color (default: white): " FONT_COLOR
    FONT_COLOR=${FONT_COLOR:-white}  # Default to white if not provided

    # Validate font color
    if [[ ! "$FONT_COLOR" =~ ^([a-zA-Z]+|#[0-9A-Fa-f]{6})$ ]]; then
        echo "Invalid color format. Please use a named color (e.g., 'white') or a hex code (e.g., '#FFFFFF')."
        exit 1
    fi

    read -p "Start time for the text (format: HH:MM:SS or SS) [default: start of video]: " START_TIME
    START_TIME=${START_TIME:-0}  # Default to 0 if not provided

    read -p "End time for the text (format: HH:MM:SS or SS) [default: end of video]: " END_TIME
}

# Call the function to collect arguments
collect_arguments

# Temporary video file
TEMP_VIDEO="temp_video.mp4"

# Debug output of collected values
echo "DEBUG: INPUT_VIDEO='$INPUT_VIDEO'"
echo "DEBUG: OUTPUT_VIDEO='$OUTPUT_VIDEO'"
echo "DEBUG: TEXT='$TEXT'"
echo "DEBUG: X_POSITION='$X_POSITION'"
echo "DEBUG: Y_POSITION='$Y_POSITION'"
echo "DEBUG: FONT_COLOR='$FONT_COLOR'"
echo "DEBUG: START_TIME='$START_TIME'"
echo "DEBUG: END_TIME='$END_TIME'"

# Construct the drawtext filter with start and end time
if [ -z "$END_TIME" ]; then
    # No end time specified
    FILTER="drawtext=text='${TEXT//:/\\:}':x=$X_POSITION:y=$Y_POSITION:fontcolor=$FONT_COLOR:fontsize=118:enable='gte(t,$START_TIME)'"
else
    # Both start and end time specified
    FILTER="drawtext=text='${TEXT//:/\\:}':x=$X_POSITION:y=$Y_POSITION:fontcolor=$FONT_COLOR:fontsize=118:enable='between(t,$START_TIME,$END_TIME)'"
fi

# Debug output of the filter
echo "DEBUG: FILTER='$FILTER'"

# Add text to video
ffmpeg -i "$INPUT_VIDEO" -vf "$FILTER" -codec:a copy "$TEMP_VIDEO"

# Check if FFmpeg was successful before proceeding
if [ $? -eq 0 ]; then
    # If "delete" option is provided, remove the text after processing
    if [ "$DELETE" == "delete" ]; then
        mv "$INPUT_VIDEO" "${INPUT_VIDEO}.bak"  # Backup original video
        mv "$TEMP_VIDEO" "$OUTPUT_VIDEO"        # Rename temporary video to output
        rm "${INPUT_VIDEO}.bak"                 # Delete backup
    else
        mv "$TEMP_VIDEO" "$OUTPUT_VIDEO"        # Rename temporary video to output
    fi
    echo "Processing complete!"
else
    echo "Error during processing!"
fi

