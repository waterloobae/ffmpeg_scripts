#!/bin/bash

# Function to check if Docker is running
is_docker_running() {
    docker info > /dev/null 2>&1
    local status=$?
    echo "Docker info command exit status: $status" >> /var/log/docker_monitor.log
    return $status
}

# Function to restart Docker and start containers
restart_docker() {
    /home/thbae/bin/docker_restart.sh
    docker compose -f /home/thbae/Desktop/Docker-Projects/waterloobae/docker-compose.yml up -d
}

# Infinite loop to check Docker status
while true; do
    if ! is_docker_running; then
        echo "$(date): Docker is not running. Restarting Docker and containers..." >> /var/log/docker_monitor.log
        restart_docker
        echo "$(date): Docker and containers have been started." >> /var/log/docker_monitor.log
    else
        echo "$(date): Docker is running fine." >> /var/log/docker_monitor.log
    fi
    sleep 300  # Check every 5 minutes
done
